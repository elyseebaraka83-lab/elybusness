-- Création de la base de données
CREATE DATABASE IF NOT EXISTS `elybusiness` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `elybusiness`;

-- Table 1: Paramètres généraux du site
CREATE TABLE IF NOT EXISTS `settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 2: Articles / Produits
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `stock` INT NOT NULL DEFAULT 15,
  `description` TEXT NOT NULL,
  `image` LONGTEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 3: Utilisateurs (Clients)
CREATE TABLE IF NOT EXISTS `users` (
  `email` VARCHAR(191) PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 4: Commandes
CREATE TABLE IF NOT EXISTS `orders` (
  `id` VARCHAR(50) PRIMARY KEY,
  `user_email` VARCHAR(191) NOT NULL,
  `user_name` VARCHAR(255) NOT NULL,
  `order_date` VARCHAR(100) NOT NULL,
  `total` DECIMAL(10,2) NOT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'En attente',
  FOREIGN KEY (`user_email`) REFERENCES `users` (`email`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 5: Articles de commandes
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(50) NOT NULL,
  `product_id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `quantity` INT NOT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Insertion des paramètres par défaut si la table est vide
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`) VALUES
('welcomeTitle', 'Bienvenue sur le site ElyBusiness'),
('welcomeDesc', 'Votre partenaire de confiance pour tous vos besoins de recharges (crédits, méga, minutes), d\'accessoires de mode, d\'appareils électroniques, de vêtements et bien plus encore.'),
('whatsappNumber', '+243981470106'),
('emailAddress', 'elyseebaraka83@gmail.com'),
('physicalAddress', 'Goma, DRC'),
('facebookLink', 'https://facebook.com/elyseebaraka'),
('instagramLink', 'https://instagram.com/elyseebaraka'),
('ceoName', 'Elysée BARAKA'),
('ceoBio', 'Chez ElyBusiness, notre priorité absolue est la satisfaction du client. Nous croyons que la technologie et les accessoires de qualité doivent être accessibles à tous rapidement et en toute sécurité. Nous continuons d\'innover pour vous apporter des solutions adaptées à vos besoins financiers et de communication.'),
('ceoPhoto', 'assets/extracted_img_1.jpg'),
('aboutImg', 'assets/extracted_img_3.jpg'),
('logoImg', 'assets/logo.svg');

-- Insertion des produits par défaut si la table est vide
INSERT IGNORE INTO `products` (`id`, `name`, `category`, `price`, `stock`, `description`, `image`) VALUES
('prod-1', 'Recharge Crédit Unités', 'crédits', 1.00, 50, 'Recharge de crédit d\'appel immédiate toutes directions. Valable pour tous les réseaux.', 'assets/extracted_img_0.jpg'),
('prod-2', 'Forfait Internet Méga', 'crédits', 0.50, 100, 'Forfait internet ultra-rapide (Méga octets) pour rester connecté sur vos réseaux préférés.', 'assets/extracted_img_0.jpg'),
('prod-3', 'Forfait Minutes d\'Appel', 'crédits', 2.00, 40, 'Minutes d\'appel longue durée à des tarifs préférentiels. Idéal pour vos besoins professionnels.', 'assets/extracted_img_0.jpg'),
('prod-4', 'Casquette Premium ElyBusiness', 'accessoires', 5.00, 15, 'Casquette stylée avec logo EB brodé. Coton de haute qualité et taille ajustable.', 'assets/extracted_img_2.jpg'),
('prod-5', 'Pochette de Protection Smartphone', 'accessoires', 3.00, 25, 'Pochette antichoc élégante, disponible pour tous modèles de smartphones.', 'assets/extracted_img_2.jpg'),
('prod-6', 'Radio Portable Transistor', 'accessoires', 12.00, 8, 'Radio portable haute sensibilité avec port USB, lecteur carte SD et lampe torche intégrée.', 'assets/extracted_img_2.jpg'),
('prod-7', 'Ordinateur Portable Pro', 'électronique', 250.00, 3, 'Ordinateur portable performant Core i5, 8 Go RAM, 256 Go SSD. Parfait pour les études et le travail.', 'assets/extracted_img_3.jpg'),
('prod-8', 'Smartphone NextGen', 'électronique', 85.00, 6, 'Smartphone avec grand écran 6.5 pouces, batterie longue durée 5000mAh et double caméra photo.', 'assets/extracted_img_3.jpg'),
('prod-9', 'T-shirt Branding EB', 'habits', 7.50, 20, 'T-shirt 100% coton arborant fièrement le logo EB. Disponible en plusieurs tailles.', 'assets/extracted_img_0.jpg'),
('prod-10', 'Blazer Cérémonie Rouge', 'habits', 35.00, 4, 'Veste blazer de coupe slim moderne. Tissu haut de gamme de couleur rouge éclatante.', 'assets/extracted_img_1.jpg');
